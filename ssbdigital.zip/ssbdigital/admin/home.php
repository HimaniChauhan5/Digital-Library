<?php include './template/header.php'; ?>

<div id="statistics"></div>
	
	<div class="box box-success">
		<div class="box-header with-border">
			<h3 class="box-title"><i class="fa fa-fw fa-book"></i> Books Statistics</h3>
		</div>
		
		<div class="box-body">

			<div id="disptotalBooks"></div>

			<canvas id="pieBooksGenre" width="409" height="130"></canvas>

		</div>
	</div>


<?php include './template/footer.php'; ?>