<div class="overlay">
	<div class="popup">
		<div class="sk-circle">
		  <div class="sk-circle1 sk-child"></div>
		  <div class="sk-circle2 sk-child"></div>
		  <div class="sk-circle3 sk-child"></div>
		  <div class="sk-circle4 sk-child"></div>
		  <div class="sk-circle5 sk-child"></div>
		  <div class="sk-circle6 sk-child"></div>
		  <div class="sk-circle7 sk-child"></div>
		  <div class="sk-circle8 sk-child"></div>
		  <div class="sk-circle9 sk-child"></div>
		  <div class="sk-circle10 sk-child"></div>
		  <div class="sk-circle11 sk-child"></div>
		  <div class="sk-circle12 sk-child"></div>
		 </div>
	</div>
</div>
	 
	 </section>
    </div>
	
	<footer class="main-footer">
       <p style="text-align: center;"> <strong>Copyright &copy; 2020.</strong> All rights reserved BY VIKRANTUP72</p>
      </footer>

    <script src="./template/plugins/jQuery/jQuery-2.1.4.min.js"></script>
	<script src="./template/scripts/alertify.min.js"></script>
    <script src="./template/bootstrap/js/bootstrap.min.js"></script>
    <script src="./template/js/app.min.js"></script>
    <script src="./template/js/bootstrap-select.js"></script>
	<script src="./template/scripts/script.js"></script>

	
  </body>
</html>
