<?php 
	$titlepage = "E-Books";
	include "./template/header.php";
?>

<div id="EbooksListPage"></div>

<div class="container">
	<div class="panel panel-success">
		<div class="panel-body">
				<div class="page-header">
		 		 	<h1>E-Books</h1>
				</div>
				<p>You can read the book here via PDF file.</p>

				
				  <div id="listAllEbooks"></div>
				
			<br><br><br>
		</div>	
	</div>
	<br><br><br>
</div>

<?php include "./template/footer.php"; ?>