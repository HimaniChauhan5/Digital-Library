<?php 
	$titlepage = "About Us";
	include "./template/header.php";
?>

<div class="container">
	<div class="panel panel-success">
		<div class="panel-body">
				<div class="page-header">
		 		 	<h1>About Us</h1>
				</div>
				<h3>
				Hi, I'm Vikrant Upadhyay.
				</h3>
				<br>
				<p>
				A Passionate Software Developer,Entrepreneur and Coder. I love to play with coding, building software, and focusing on learning new technologies.<br><br> Currently I am pursuing MCA from UNITED INSTITUTE OF MANAGEMENT.
				</p>

			<br><br><br>
		</div>	
	</div>
	<br><br><br>
</div>

<?php include "./template/footer.php"; ?>